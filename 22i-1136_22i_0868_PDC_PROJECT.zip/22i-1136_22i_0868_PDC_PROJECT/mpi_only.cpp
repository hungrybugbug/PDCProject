#include <mpi.h>
#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include <set>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <metis.h> // Ensure METIS is properly installed and metis.h is found

using namespace std;

const int INF = numeric_limits<int>::max();

struct Edge {
    int to;
    int weight;
};

struct CompareDist {
    bool operator()(pair<int, int> a, pair<int, int> b) {
        return a.second > b.second;
    }
};

class Graph {
public:
    int n;
    vector<vector<Edge>> adjList;
    vector<int> dist;
    vector<int> parent;

    Graph(int nodes, int src) : n(nodes) {
        adjList.resize(n);
        dist.assign(n, INF);
        parent.assign(n, -1);
    }

    void addEdge(int u, int v, int w = 1) {
        adjList[u].push_back({v, w});
    }

    void removeEdge(int u, int v) {
        adjList[u].erase(remove_if(adjList[u].begin(), adjList[u].end(),
            [v](Edge e) { return e.to == v; }), adjList[u].end());
    }

    void dijkstra(int src) {
        dist.assign(n, INF);
        parent.assign(n, -1);
        dist[src] = 0;

        priority_queue<pair<int, int>, vector<pair<int, int>>, CompareDist> pq;
        pq.push({src, 0});

        while (!pq.empty()) {
            auto [u, d] = pq.top();  // C++17 structured binding
            pq.pop();

            if (d > dist[u]) continue;

            for (auto& edge : adjList[u]) {
                int v = edge.to;
                int weight = edge.weight;
                if (dist[u] != INF && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                    pq.push({v, dist[v]});
                }
            }
        }
    }

    bool relax(int z) {
        bool updated = false;
        for (int u = 0; u < n; ++u) {
            for (auto& edge : adjList[u]) {
                if (edge.to == z && dist[u] != INF && dist[u] + edge.weight < dist[z]) {
                    dist[z] = dist[u] + edge.weight;
                    parent[z] = u;
                    updated = true;
                }
            }
        }
        return updated;
    }

    void updateSSSP(int u, int v, int weight, bool isInsert) {
        int x = (dist[u] > dist[v]) ? u : v;
        int y = (x == u) ? v : u;

        if (isInsert) {
            addEdge(u, v, weight);
            if (dist[y] != INF && dist[y] + weight < dist[x]) {
                dist[x] = dist[y] + weight;
                parent[x] = y;
            }
        } else {
            removeEdge(u, v);
            dist[x] = INF;
            parent[x] = -1;
        }

        priority_queue<pair<int, int>, vector<pair<int, int>>, CompareDist> pq;
        pq.push({x, dist[x]});

        while (!pq.empty()) {
            int z = pq.top().first;
            pq.pop();

            if (relax(z)) {
                for (auto& edge : adjList[z]) {
                    pq.push({edge.to, dist[edge.to]});
                }
            }
        }
    }

    void printDistancesToFile(const string& filename) {
        ofstream out(filename);
        for (int i = 0; i < n; ++i) {
            if (dist[i] == INF)
                out << "Node " << i << ": unreachable\n";
            else
                out << "Node " << i << ": " << dist[i] << "\n";
        }
        out.close();
    }
};

Graph loadGraph(const string& filename, int& maxNode) {
    ifstream infile(filename);
    string line;
    int u, v;
    maxNode = 0;
    vector<pair<int, int>> edges;

    while (getline(infile, line)) {
        istringstream iss(line);
        if (!(iss >> u >> v)) continue;
        maxNode = max(maxNode, max(u, v));
        edges.push_back({u, v});
    }

    Graph g(maxNode + 1, 0);
    for (auto& e : edges) {
        g.addEdge(e.first, e.second, 1);
    }

    return g;
}

void partitionGraphWithMETIS(int rank, int size, Graph& g, vector<int>& part, vector<vector<Edge>>& localAdjList) {
    idx_t n = g.n;
    idx_t ncon = 1;
    idx_t nparts = size;
    idx_t objval;

    vector<idx_t> xadj;
    vector<idx_t> adjncy;
    xadj.push_back(0);
    for (int i = 0; i < g.n; ++i) {
        for (const auto& edge : g.adjList[i]) {
            adjncy.push_back(edge.to);
        }
        xadj.push_back(adjncy.size());
    }

    part.resize(n);
    int status = METIS_PartGraphKway(
        &n, &ncon, xadj.data(), adjncy.data(),
        NULL, NULL, NULL,
        &nparts, NULL, NULL, NULL,
        &objval, part.data()
    );

    if (status != METIS_OK) {
        if (rank == 0) {
            cerr << "METIS_PartGraphKway failed with code " << status << endl;
        }
        MPI_Abort(MPI_COMM_WORLD, status);
    }

    for (int i = 0; i < n; ++i) {
        if (part[i] == rank) {
            localAdjList.push_back(g.adjList[i]);
        }
    }
}

int main(int argc, char** argv) {
    MPI_Init(&argc, &argv);
    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int maxNode;
    Graph g = loadGraph("web-Google.txt", maxNode);

    vector<int> part;
    vector<vector<Edge>> localAdjList;
    partitionGraphWithMETIS(rank, size, g, part, localAdjList);

    double startTime, endTime, totalTime;

    if (rank == 0) {
        startTime = MPI_Wtime();
        g.dijkstra(0);
        endTime = MPI_Wtime();
        totalTime = endTime - startTime;
        cout << "Initial SSSP computed from source 0 in " << totalTime << " seconds.\n";

        ofstream logfile("performance.csv", ios::app);
        if (logfile.is_open()) {
            logfile << "mpi_metis,web-Google.txt," << totalTime << "\n";
            logfile.close();
        } else {
            cerr << "Error: Could not open performance.csv for writing.\n";
        }
    }

    MPI_Bcast(g.dist.data(), g.n, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        startTime = MPI_Wtime();
        g.updateSSSP(4, 6, 1, false);
        endTime = MPI_Wtime();
        cout << "Edge update time: " << endTime - startTime << " seconds\n";
        g.printDistancesToFile("mpi_updated_distances.txt");

        int ret = system("python3 visual.py");
        if (ret != 0) {
            cerr << "Warning: Failed to run visual.py. Ensure it exists and is error-free.\n";
        }
    }

    MPI_Bcast(g.dist.data(), g.n, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Finalize();
    return 0;
}
