#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include <chrono>   

using namespace std;

const int INF = numeric_limits<int>::max();
const int MAX_NODE_LIMIT = 1000000; // Adjust if needed

class Graph {
private:
    unordered_map<int, vector<int>> adjList;
    int maxNode = 0;

public:
    void loadGraphFromFile(const string& filename) {
        ifstream infile(filename);
        if (!infile.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            exit(1);
        }

        string line;
        while (getline(infile, line)) {
            // Skip comment lines
            if (line.empty() || line[0] == '#') continue;

            stringstream ss(line);
            int u, v;
            ss >> u >> v;

            if (u > MAX_NODE_LIMIT || v > MAX_NODE_LIMIT) {
                cerr << "Skipping invalid line: " << line << endl;
                continue;
            }

            adjList[u].push_back(v);

            maxNode = max(maxNode, max(u, v));
        }

        infile.close();
        cout << "Graph loaded. Max node ID: " << maxNode << endl;
    }

    vector<int> bfsShortestPaths(int source) {
        vector<int> distance(maxNode + 1, INF);
        queue<int> q;

        distance[source] = 0;
        q.push(source);

        while (!q.empty()) {
            int u = q.front();
            q.pop();

            for (int v : adjList[u]) {
                if (distance[v] == INF) {
                    distance[v] = distance[u] + 1;
                    q.push(v);
                }
            }
        }

        return distance;
    }

    int getMaxNode() const {
        return maxNode;
    }
};

int main() {
    auto start = chrono::high_resolution_clock::now();
    Graph g;
    string filename = "deleted.txt";

    g.loadGraphFromFile(filename);

    int sourceNode = 0;
    cout << "Running BFS from source node: " << sourceNode << endl;

    vector<int> distances = g.bfsShortestPaths(sourceNode);

    // Count and summarize
    int reachable = 0;
    int unreachable = 0;
    vector<int> unreachableNodes;

    for (int i = 0; i <= g.getMaxNode(); ++i) {
        if (distances[i] == INF) {
            ++unreachable;
            if (unreachableNodes.size() < 10) // limit to first 10 shown
                unreachableNodes.push_back(i);
        } else {
            ++reachable;
        }
    }

    cout << "\n=== BFS Reachability Summary ===\n";
    cout << "Total nodes (0 to " << g.getMaxNode() << "): " << g.getMaxNode() + 1 << "\n";
    cout << "Reachable nodes: " << reachable << "\n";
    cout << "Unreachable nodes: " << unreachable << "\n";

    if (!unreachableNodes.empty()) {
        cout << "Example unreachable node IDs: ";
        for (int id : unreachableNodes)
            cout << id << " ";
        cout << "\n";
    }

    // Optional: Save distances to a file for further analysis
    
    ofstream outfile("distances_output.txt");
    for (int i = 0; i <= g.getMaxNode(); ++i) {
        if (distances[i] == INF)
            outfile << i << " unreachable\n";
        else
            outfile << i << " " << distances[i] << "\n";
    }
    outfile.close();
    

    auto end = chrono::high_resolution_clock::now();
    double duration = chrono::duration<double>(end - start).count();
    cout << "Sequential Execution Time: " << duration << " seconds\n";

    return 0;
}
