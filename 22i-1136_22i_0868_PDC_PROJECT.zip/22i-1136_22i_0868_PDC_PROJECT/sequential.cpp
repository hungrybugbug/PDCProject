#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <limits>
#include <set>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <chrono>
#include <cstdlib>

using namespace std;

const int INF = numeric_limits<int>::max();

struct Edge {
    int to;
    int weight;
};

struct CompareDist {
    bool operator()(pair<int, int> a, pair<int, int> b) {
        return a.second > b.second;
    }
};

class Graph {
public:
    int n;
    vector<vector<Edge>> adjList;
    vector<int> dist;
    vector<int> parent;
    int source;

    Graph(int nodes, int src) : n(nodes), source(src) {
        adjList.resize(n);
        dist.assign(n, INF);
        parent.assign(n, -1);
    }

    void addEdge(int u, int v, int w = 1) {
        adjList[u].push_back({v, w});
    }

    void removeEdge(int u, int v) {
        adjList[u].erase(remove_if(adjList[u].begin(), adjList[u].end(),
            [v](Edge e) { return e.to == v; }),
            adjList[u].end());
    }

    void dijkstra(int src) {
        dist.assign(n, INF);
        parent.assign(n, -1);
        dist[src] = 0;
        priority_queue<pair<int, int>, vector<pair<int, int>>, CompareDist> pq;
        pq.push({src, 0});

        while (!pq.empty()) {
            auto [u, d] = pq.top();
            pq.pop();

            if (d > dist[u]) continue;

            for (auto& edge : adjList[u]) {
                int v = edge.to;
                int weight = edge.weight;
                if (dist[u] != INF && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                    pq.push({v, dist[v]});
                }
            }
        }
    }

    bool relax(int z) {
        bool updated = false;
        for (int u = 0; u < n; ++u) {
            for (auto& edge : adjList[u]) {
                if (edge.to == z) {
                    if (dist[u] != INF && dist[u] + edge.weight < dist[z]) {
                        dist[z] = dist[u] + edge.weight;
                        parent[z] = u;
                        updated = true;
                    }
                }
            }
        }
        return updated;
    }

    void updateSSSP(int u, int v, int weight, bool isInsert) {
        int x, y;
        if (dist[u] > dist[v]) {
            x = u;
            y = v;
        } else {
            x = v;
            y = u;
        }

        if (isInsert) {
            addEdge(u, v, weight);
            if (dist[y] != INF && dist[y] + weight < dist[x]) {
                dist[x] = dist[y] + weight;
                parent[x] = y;
            }
        } else {
            removeEdge(u, v);
            dist[x] = INF;
            parent[x] = -1;
        }

        priority_queue<pair<int, int>, vector<pair<int, int>>, CompareDist> pq;
        pq.push({x, dist[x]});

        while (!pq.empty()) {
            int z = pq.top().first;
            pq.pop();

            if (relax(z)) {
                for (auto& edge : adjList[z]) {
                    pq.push({edge.to, dist[edge.to]});
                }
            }
        }
    }

    void printDistancesToFile(const string& filename) {
        ofstream out(filename);
        for (int i = 0; i < n; ++i) {
            if (dist[i] == INF)
                out << "Node " << i << ": unreachable\n";
            else
                out << "Node " << i << ": " << dist[i] << "\n";
        }
        out.close();
    }
};

// Load graph from file assuming all weights = 1
Graph loadGraph(const string& filename, int& maxNode) {
    ifstream infile(filename);
    string line;
    int u, v;
    maxNode = 0;
    vector<pair<int, int>> edges;

    while (getline(infile, line)) {
        istringstream iss(line);
        if (!(iss >> u >> v)) continue;
        maxNode = max(maxNode, max(u, v));
        edges.push_back({u, v});
    }

    Graph g(maxNode + 1, 0);
    for (auto& e : edges) {
        g.addEdge(e.first, e.second, 1);
    }

    return g;
}


int main() {
    int maxNode;
    Graph g = loadGraph("web-Google.txt", maxNode);

    // Measure execution time of Dijkstra
    auto start = std::chrono::high_resolution_clock::now();
    g.dijkstra(0);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> elapsed = end - start;
    std::cout << "Initial SSSP computed from source 0 in " << elapsed.count() << " seconds.\n";

    // Save time to performance log
    std::ofstream logfile("performance.csv", std::ios::app);
    if (logfile.is_open()) {
        logfile << "sequential,web-Google.txt," << elapsed.count() << "\n";
        logfile.close();
        std::cout << "Performance logged to 'performance.csv'\n";
    } else {
        std::cerr << "Error: Could not open performance.csv for writing.\n";
    }

    // Simulate deletion of edge (4, 6)
    g.updateSSSP(4, 6, 1, false);

    std::cout << "After edge update.\n";
    g.printDistancesToFile("updated_distances.txt");
    std::cout << "Distances written to 'updated_distances.txt'\n";

    // Run the Python script for visualization
    int ret = system("python3 visual.py");
    if (ret != 0) {
        std::cerr << "Warning: Failed to run visual.py. Ensure it exists and is error-free.\n";
    }

    return 0;
}