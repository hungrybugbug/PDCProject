#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <sstream>
#include <string>
#include <limits>
#include <algorithm>
#include <omp.h>
#include <mpi.h>
#include <atomic>

using namespace std;

const int INF = numeric_limits<int>::max();

// Simplified edge structure to improve cache locality
struct Edge {
    int to, weight;
    Edge(int t, int w = 1) : to(t), weight(w) {}
};

class Graph {
public:
    int n; // number of nodes
    vector<vector<Edge>> adjList;
    vector<int> dist, parent;
    vector<bool> affected; // Track affected vertices for dynamic updates

    Graph(int nodes) : n(nodes) {
        adjList.resize(n);
        dist.resize(n, INF);
        parent.resize(n, -1);
        affected.resize(n, false);
    }

    void addEdge(int u, int v, int w = 1) {
        adjList[u].emplace_back(v, w);
        adjList[v].emplace_back(u, w); // undirected
    }

    void removeEdge(int u, int v) {
        // Mark vertices as affected by the deletion
        if (parent[v] == u) {
            affected[v] = true;
        } else if (parent[u] == v) {
            affected[u] = true;
        }
        
        // Remove edge from adjacency lists
        adjList[u].erase(remove_if(adjList[u].begin(), adjList[u].end(),
                                   [v](const Edge &e) { return e.to == v; }),
                         adjList[u].end());

        adjList[v].erase(remove_if(adjList[v].begin(), adjList[v].end(),
                                   [u](const Edge &e) { return e.to == u; }),
                         adjList[v].end());
    }
    
    // Method to process edge deletion updates asynchronously (based on Algorithm 4)
    void processEdgeDeletionUpdates(int levelOfAsynchrony = 2) {
        bool change = true;
        
        while (change) {
            change = false;
            
            #pragma omp parallel
            {
                vector<int> localAffected;
                
                #pragma omp for schedule(dynamic, 64)
                for (int v = 0; v < n; v++) {
                    if (affected[v]) {
                        // Initialize queue for BFS
                        queue<int> Q;
                        Q.push(v);
                        
                        int level = 0;
                        
                        while (!Q.empty()) {
                            int x = Q.front();
                            Q.pop();
                            
                            // Process children in the shortest path tree
                            for (int c = 0; c < n; c++) {
                                if (parent[c] == x) {
                                    // Mark child as affected
                                    #pragma omp critical
                                    {
                                        if (!affected[c]) {
                                            affected[c] = true;
                                            localAffected.push_back(c);
                                            change = true;
                                        }
                                    }
                                    
                                    // Set distance to infinity
                                    dist[c] = INF;
                                    
                                    // Process next level asynchronously if within limit
                                    level++;
                                    if (level <= levelOfAsynchrony) {
                                        Q.push(c);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Sequential Dijkstra implementation for comparison
    void dijkstra_sequential(int src) {
        fill(dist.begin(), dist.end(), INF);
        fill(parent.begin(), parent.end(), -1);
        dist[src] = 0;
        
        vector<bool> processed(n, false);
        
        for (int i = 0; i < n; i++) {
            // Find minimum distance vertex
            int u = -1;
            int minDist = INF;
            for (int j = 0; j < n; j++) {
                if (!processed[j] && dist[j] < minDist) {
                    minDist = dist[j];
                    u = j;
                }
            }
            
            if (u == -1) break;  // No reachable nodes left
            processed[u] = true;
            
            // Process all neighbors
            for (const Edge& edge : adjList[u]) {
                int v = edge.to;
                int weight = edge.weight;
                
                if (dist[u] != INF && dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    parent[v] = u;
                }
            }
        }
    }

    // Optimized OpenMP implementation
    void dijkstra_openmp_optimized(int src) {
        const int CHUNK_SIZE = 1024; // Tune this based on your graph
        
        fill(dist.begin(), dist.end(), INF);
        fill(parent.begin(), parent.end(), -1);
        dist[src] = 0;
        
        vector<bool> processed(n, false);
        
        // Use an array-based approach for larger graphs
        for (int iter = 0; iter < n; iter++) {
            // Find minimum distance vertex (sequential, as it's typically fast)
            int u = -1;
            int minDist = INF;
            
            for (int j = 0; j < n; j++) {
                if (!processed[j] && dist[j] < minDist) {
                    minDist = dist[j];
                    u = j;
                }
            }
            
            if (u == -1) break;  // No reachable nodes left
            processed[u] = true;
            
            // Parallelize the edge processing with better chunking
            if (adjList[u].size() > CHUNK_SIZE) {
                #pragma omp parallel
                {
                    // Use thread-local variables to avoid false sharing
                    vector<pair<int, int>> localUpdates;
                    
                    #pragma omp for schedule(dynamic, 64)
                    for (size_t j = 0; j < adjList[u].size(); j++) {
                        const Edge& edge = adjList[u][j];
                        int v = edge.to;
                        int weight = edge.weight;
                        
                        if (dist[u] != INF && dist[u] + weight < dist[v]) {
                            localUpdates.emplace_back(v, dist[u] + weight);
                        }
                    }
                    
                    // Apply updates with minimal critical section
                    #pragma omp critical
                    {
                        for (const auto& update : localUpdates) {
                            int v = update.first;
                            int newDist = update.second;
                            if (newDist < dist[v]) {
                                dist[v] = newDist;
                                parent[v] = u;
                            }
                        }
                    }
                }
            } else {
                // Process sequentially for small adjacency lists
                for (const Edge& edge : adjList[u]) {
                    int v = edge.to;
                    int weight = edge.weight;
                    
                    if (dist[u] != INF && dist[u] + weight < dist[v]) {
                        dist[v] = dist[u] + weight;
                        parent[v] = u;
                    }
                }
            }
        }
    }

    // Delta-stepping algorithm - more efficient for large graphs
    void delta_stepping(int src, int delta = 3) {
        fill(dist.begin(), dist.end(), INF);
        fill(parent.begin(), parent.end(), -1);
        dist[src] = 0;
        
        // Buckets to store vertices based on distance
        vector<vector<int>> buckets;
        buckets.resize(n); // We'll resize as needed
        buckets[0].push_back(src);
        
        int currentBucket = 0;
        
        while (true) {
            // Find the first non-empty bucket
            while (currentBucket < buckets.size() && buckets[currentBucket].empty()) {
                currentBucket++;
            }
            
            if (currentBucket >= buckets.size()) break;
            
            // Process all vertices in the current bucket in parallel batches
            vector<int> current = std::move(buckets[currentBucket]);
            
            while (!current.empty()) {
                vector<tuple<int, int, int>> updates; // (node, dist, parent)
                
                #pragma omp parallel
                {
                    vector<tuple<int, int, int>> localUpdates;
                    
                    #pragma omp for schedule(dynamic, 256)
                    for (size_t i = 0; i < current.size(); i++) {
                        int u = current[i];
                        
                        // Process light edges (weight <= delta)
                        for (const Edge& edge : adjList[u]) {
                            int v = edge.to;
                            int weight = edge.weight;
                            
                            if (weight <= delta) {
                                int newDist = dist[u] + weight;
                                if (newDist < dist[v]) {
                                    localUpdates.emplace_back(v, newDist, u);
                                }
                            }
                        }
                    }
                    
                    #pragma omp critical
                    {
                        updates.insert(updates.end(), localUpdates.begin(), localUpdates.end());
                    }
                }
                
                // Apply updates sequentially to avoid race conditions
                vector<int> newVertices;
                for (const auto& [v, newDist, p] : updates) {
                    if (newDist < dist[v]) {
                        if (dist[v] == INF) {
                            // New vertex discovered
                            newVertices.push_back(v);
                        } else {
                            // Remove from its current bucket if it exists
                            int oldBucket = dist[v] / delta;
                            if (oldBucket < buckets.size()) {
                                auto& bucket = buckets[oldBucket];
                                bucket.erase(remove(bucket.begin(), bucket.end(), v), bucket.end());
                            }
                        }
                        
                        // Update distance and parent
                        dist[v] = newDist;
                        parent[v] = p;
                        
                        // Add to appropriate bucket
                        int newBucket = newDist / delta;
                        if (newBucket >= buckets.size()) {
                            buckets.resize(newBucket + 1);
                        }
                        buckets[newBucket].push_back(v);
                    }
                }
                
                // Process heavy edges for the new vertices
                updates.clear();
                
                #pragma omp parallel
                {
                    vector<tuple<int, int, int>> localUpdates;
                    
                    #pragma omp for schedule(dynamic, 256)
                    for (size_t i = 0; i < newVertices.size(); i++) {
                        int u = newVertices[i];
                        
                        // Process heavy edges (weight > delta)
                        for (const Edge& edge : adjList[u]) {
                            int v = edge.to;
                            int weight = edge.weight;
                            
                            if (weight > delta) {
                                int newDist = dist[u] + weight;
                                if (newDist < dist[v]) {
                                    localUpdates.emplace_back(v, newDist, u);
                                }
                            }
                        }
                    }
                    
                    #pragma omp critical
                    {
                        updates.insert(updates.end(), localUpdates.begin(), localUpdates.end());
                    }
                }
                
                // Apply heavy edge updates
                for (const auto& [v, newDist, p] : updates) {
                    if (newDist < dist[v]) {
                        if (dist[v] == INF) {
                            // New vertex discovered
                            current.push_back(v);
                        } else {
                            // Remove from its current bucket if it exists
                            int oldBucket = dist[v] / delta;
                            if (oldBucket < buckets.size()) {
                                auto& bucket = buckets[oldBucket];
                                bucket.erase(remove(bucket.begin(), bucket.end(), v), bucket.end());
                            }
                        }
                        
                        // Update distance and parent
                        dist[v] = newDist;
                        parent[v] = p;
                        
                        // Add to appropriate bucket
                        int newBucket = newDist / delta;
                        if (newBucket >= buckets.size()) {
                            buckets.resize(newBucket + 1);
                        }
                        buckets[newBucket].push_back(v);
                    }
                }
                
                // Clear current vertices since we've processed them
                current.clear();
                
                // Get next batch from the current bucket
                if (!buckets[currentBucket].empty()) {
                    current = std::move(buckets[currentBucket]);
                }
            }
        }
    }

    void saveOutputToFile(const string& filename) {
        ofstream outFile(filename);
        if (!outFile.is_open()) {
            cerr << "Error opening output file!" << endl;
            return;
        }

        for (int i = 0; i < n; ++i) {
            outFile << "Vertex " << i << ": ";
            if (dist[i] == INF)
                outFile << "Unreachable";
            else
                outFile << "Distance = " << dist[i] << ", Parent = " << parent[i];
            outFile << endl;
        }

        outFile.close();
    }

    void printShortestPaths(int limit = 10) {
        for (int i = 0; i < min(limit, n); ++i) {
            cout << "Vertex " << i << ": ";
            if (dist[i] == INF)
                cout << "Unreachable";
            else
                cout << "Distance = " << dist[i] << ", Parent = " << parent[i];
            cout << endl;
        }
    }
};

int getMaxNodeInFile(const string &filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening input file: " << filename << endl;
        return -1;
    }
    
    string line;
    int maxNode = 0;

    while (getline(file, line)) {
        istringstream iss(line);
        int u, v;
        if (iss >> u >> v) {
            maxNode = max(maxNode, max(u, v));
        }
    }
    
    file.close();
    return maxNode;
}

// Function to load graph efficiently
bool loadGraphEfficiently(const string& filename, Graph& g) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error opening input file: " << filename << endl;
        return false;
    }
    
    // Pre-allocate edge vectors based on estimated average degree
    int avgDegree = 5; // Adjust based on your graph characteristics
    for (int i = 0; i < g.n; i++) {
        g.adjList[i].reserve(avgDegree);
    }
    
    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        int u, v;
        if (iss >> u >> v) {
            g.addEdge(u, v, 1);
        }
    }
    file.close();
    return true;
}

int main(int argc, char *argv[]) {
    // Initialize MPI
    MPI_Init(&argc, &argv);

    int rank, numProcesses;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numProcesses);

    string filename = "email.txt";
    int algorithm = 0; // 0=sequential, 1=openmp, 2=delta-stepping

    for (int i = 1; i < argc; i++) {
        string arg = argv[i];
        if (arg == "-f" && i + 1 < argc) {
            filename = argv[++i];
        } else if (arg == "-a" && i + 1 < argc) {
            algorithm = atoi(argv[++i]);
        }
    }

    int maxNode = 0;
    if (rank == 0) {
        maxNode = getMaxNodeInFile(filename);
    }
    MPI_Bcast(&maxNode, 1, MPI_INT, 0, MPI_COMM_WORLD);

    Graph g(maxNode + 1);
    if (rank == 0) {
        loadGraphEfficiently(filename, g);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double start_time = MPI_Wtime();

    if (algorithm == 0) {
        g.dijkstra_sequential(0);
    } else if (algorithm == 1) {
        g.dijkstra_openmp_optimized(0);
    } else {
        g.delta_stepping(0);
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double end_time = MPI_Wtime();

    if (rank == 0) {
        double elapsed = end_time - start_time;
        string algo_name = (algorithm == 0) ? "sequential" : (algorithm == 1) ? "openmp" : "Dijkastra";

        // Log performance data
        ofstream logfile("performance.csv", ios::app);
        if (logfile.is_open()) {
            logfile << algo_name << "," << filename << "," << elapsed << endl;
            logfile.close();
            cout << "Performance logged to 'performance.csv'" << endl;
        } else {
            cerr << "Error: Could not open performance.csv for writing." << endl;
        }

        // Optionally save distances
        g.saveOutputToFile("output.txt");

        // Run visualization script
        int ret = system("python3 visual.py");
        if (ret != 0) {
            cerr << "Warning: Failed to run visual.py. Ensure it exists and is error-free." << endl;
        }

        // Show timing
        cout << "Execution time: " << elapsed << " seconds" << endl;
    }

    MPI_Finalize();
    return 0;
}
