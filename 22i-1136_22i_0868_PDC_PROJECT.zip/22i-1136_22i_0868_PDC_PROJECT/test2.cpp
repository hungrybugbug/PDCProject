#include <mpi.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <limits>
#include <unordered_set>

using namespace std;

const int INF = numeric_limits<int>::max();

class Graph {
public:
    int maxNode = 0;
    vector<vector<int>> adjList;

    void loadGraphFromFile(const string& filename) {
        ifstream infile(filename);
        if (!infile.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        string line;
        vector<pair<int, int>> edges;

        while (getline(infile, line)) {
            if (line[0] == '#') continue;

            stringstream ss(line);
            int u, v;
            ss >> u >> v;

            edges.emplace_back(u, v);
            maxNode = max(maxNode, max(u, v));
        }

        infile.close();
        adjList.resize(maxNode + 1);
        for (auto& e : edges) {
            adjList[e.first].push_back(e.second);
        }

        cout << "Graph loaded. Max node ID: " << maxNode << endl;
    }

    void broadcastGraph(int rank) {
        MPI_Bcast(&maxNode, 1, MPI_INT, 0, MPI_COMM_WORLD);

        if (rank != 0) {
            adjList.resize(maxNode + 1);
        }

        for (int i = 0; i <= maxNode; ++i) {
            int size = (rank == 0) ? adjList[i].size() : 0;
            MPI_Bcast(&size, 1, MPI_INT, 0, MPI_COMM_WORLD);

            if (rank != 0) adjList[i].resize(size);
            if (size > 0)
                MPI_Bcast(adjList[i].data(), size, MPI_INT, 0, MPI_COMM_WORLD);
        }
    }
};

void parallelBFS(Graph& g, int source, vector<int>& distances, int rank, int size) {
    int n = g.maxNode + 1;
    distances.assign(n, INF);
    vector<bool> visited(n, false);

    queue<int> q;

    double totalCommTime = 0.0;
    double totalCompTime = 0.0;

    if (rank == 0) {
        distances[source] = 0;
        visited[source] = true;
        q.push(source);
    }

    while (true) {
        double commStart = MPI_Wtime();
        int localCount = q.size();
        MPI_Bcast(&localCount, 1, MPI_INT, 0, MPI_COMM_WORLD);
        totalCommTime += (MPI_Wtime() - commStart);

        if (localCount == 0)
            break;

        vector<int> currentLevel(localCount);
        if (rank == 0) {
            for (int i = 0; i < localCount; ++i) {
                currentLevel[i] = q.front();
                q.pop();
            }
        }

        commStart = MPI_Wtime();
        MPI_Bcast(currentLevel.data(), localCount, MPI_INT, 0, MPI_COMM_WORLD);
        totalCommTime += (MPI_Wtime() - commStart);

        double compStart = MPI_Wtime();
        unordered_set<int> localNewSet;

        for (int i = rank; i < localCount; i += size) {
            int u = currentLevel[i];
            for (int v : g.adjList[u]) {
                if (!visited[v]) {
                    localNewSet.insert(v);
                }
            }
        }
        double compEnd = MPI_Wtime();
        totalCompTime += (compEnd - compStart);

        vector<int> localNew(localNewSet.begin(), localNewSet.end());
        int localSize = localNew.size();

        vector<int> recvCounts(size);
        commStart = MPI_Wtime();
        MPI_Gather(&localSize, 1, MPI_INT, recvCounts.data(), 1, MPI_INT, 0, MPI_COMM_WORLD);
        totalCommTime += (MPI_Wtime() - commStart);

        vector<int> displs(size, 0), allNew;
        if (rank == 0) {
            int total = 0;
            for (int i = 0; i < size; ++i) {
                displs[i] = total;
                total += recvCounts[i];
            }
            allNew.resize(total);
        }

        commStart = MPI_Wtime();
        MPI_Gatherv(localNew.data(), localSize, MPI_INT,
                    allNew.data(), recvCounts.data(), displs.data(), MPI_INT, 0, MPI_COMM_WORLD);
        totalCommTime += (MPI_Wtime() - commStart);

        if (rank == 0) {
            vector<int> nextQueue;
            for (int v : allNew) {
                if (!visited[v]) {
                    visited[v] = true;
                    distances[v] = distances[currentLevel[0]] + 1;
                    nextQueue.push_back(v);
                }
            }

            for (int v : nextQueue) {
                q.push(v);
            }
        }
    }

    // Reduce timings to root process
    double globalCommTime = 0.0, globalCompTime = 0.0;
    MPI_Reduce(&totalCommTime, &globalCommTime, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
    MPI_Reduce(&totalCompTime, &globalCompTime, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        cout << "\n=== Timing Breakdown (Summed across all ranks) ===\n";
        cout << "Total Computation Time (approx): " << globalCompTime << " seconds\n";
        cout << "Total Communication Time (approx): " << globalCommTime << " seconds\n";
    }
}

int main(int argc, char** argv) 
{
    MPI_Init(&argc, &argv);
    double start = MPI_Wtime();

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    Graph g;
    if (rank == 0) {
        g.loadGraphFromFile("web-Google.txt");
    }

    g.broadcastGraph(rank);

    int source = 0;
    vector<int> distances;

    if (rank == 0) {
        cout << "Running MPI BFS from source node: " << source << endl;
    }

    parallelBFS(g, source, distances, rank, size);

    if (rank == 0) {
        // Reachability summary
        int reachable = 0;
        int unreachable = 0;
        vector<int> unreachableSample;

        for (int i = 0; i <= g.maxNode; ++i) {
            if (distances[i] == INF) {
                ++unreachable;
                if (unreachableSample.size() < 10)
                    unreachableSample.push_back(i);
            } else {
                ++reachable;
            }
        }

        cout << "\n=== BFS Reachability Summary ===\n";
        cout << "Total nodes (0 to " << g.maxNode << "): " << (g.maxNode + 1) << "\n";
        cout << "Reachable nodes: " << reachable << "\n";
        cout << "Unreachable nodes: " << unreachable << "\n";
        cout << "Example unreachable node IDs: ";
        for (int id : unreachableSample) cout << id << " ";
        cout << "\n";
    }

    double end = MPI_Wtime();
    if (rank == 0) {
        cout << "Parallel Execution Time: " << (end - start) << " seconds\n";
    }

    MPI_Finalize();
    return 0;
}
